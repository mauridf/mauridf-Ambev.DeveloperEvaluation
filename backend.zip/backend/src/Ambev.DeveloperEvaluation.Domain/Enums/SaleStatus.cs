﻿namespace Ambev.DeveloperEvaluation.Domain.Enums
{
    public enum SaleStatus
    {
        NotCancelled = 0,
        Cancelled = 1
    }
}
